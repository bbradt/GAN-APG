#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int n;
    scanf(" %d",&n);
    if(n%2==0){
        printf("white \n");
        printf("1");
        printf("2");
}
else printf("black");

    return 0;
}
