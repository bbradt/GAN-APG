#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Dec  8 19:02:56 2017

@author: bbradt
"""

import numpy as np
import seaborn as sb
import matplotlib.pyplot as plt
import pandas as pd

tokens_clf_fn = 'clfsuite_tokens.npy'
ast_clf_fn = 'clfsuite_ast.npy'
f, (ax1, ax2) = plt.subplots(1, 2, sharey=True)
f.set_size_inches(10, 5)
tokens_clf = np.load(tokens_clf_fn)
tokens_clf = tokens_clf.item()
tokens_uw = [{"model": k, "accuracy": vi} for k, v in tokens_clf.items()
             for vi in v]
tokens_df = pd.DataFrame(tokens_uw)
order = tokens_df.groupby(by=["model"])["accuracy"].sum().iloc[::-1].index
sb.set(palette="muted")
ax = sb.boxplot(y="model", x="accuracy", data=tokens_df, ax=ax1)
ax1.set_title("Tokenized Data")
ax1.set_xlim(0.05, 0.55)

ast_clf = np.load(ast_clf_fn)
ast_clf = ast_clf.item()
ast_uw = [{"model": k, "accuracy": vi} for k, v in ast_clf.items()
          for vi in v]
ast_df = pd.DataFrame(ast_uw)
sb.set(palette="muted")
ax = sb.boxplot(y="model", x="accuracy", data=ast_df, ax=ax2)

ax2.set_title("AST Data")
ax2.set_xlim(0.05, 0.55)
ax2.set_ylabel("")
plt.tight_layout()
plt.savefig("all_clfs.pdf")
plt.show()
