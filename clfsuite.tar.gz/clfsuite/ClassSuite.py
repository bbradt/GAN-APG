#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 12 12:03:58 2017

@author: bbradt

A suite of sklearn classifiers for sequential, discrete data sets.
This module is based off of another module I wrote for another project,
with some minor changes.

"""
import numpy as np
from time import time
import pandas as pd
import itertools
import operator


from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import RidgeClassifier
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC
from sklearn.linear_model import SGDClassifier
from sklearn.linear_model import Perceptron
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.naive_bayes import BernoulliNB, MultinomialNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neighbors import NearestCentroid
from sklearn.ensemble import RandomForestClassifier
from sklearn.utils.extmath import density
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score

from sklearn import metrics


class ClassSuite():
    """
        The class-suite object allows for the running of multiple models over
        the same data set in a unified fashion.
    """

    #  List of defined classifers
    MODEL_NAMES = {'rid': 'Ridge Regression',
                   'svc': 'Linear Support Vector Machine',
                   'sgd': 'Logistic Regression',
                   'sgde': 'Logistic Regression with Elastic Net',
                   'svcf': ' Linear SVM with Feature Selection',
                   'ptc': 'Perceptron',
                   'pac': 'Passive Aggresive Classifier',
                   'bnb': 'Bernoulli Naive-Bayes',
                   'mnb': 'Multinomial Naive-Bayes',
                   'knn': 'K Nearest-Neighbors',
                   'ncc': 'Nearest Centroid Classifier',
                   }

    def __init__(self,
                 labels=['pos', 'neg'],
                 file='ast.csv',
                 models=list(MODEL_NAMES.keys()),
                 seed=314159,
                 shuffle=True,
                 class_index=0,
                 ):
        self.n_features = 2 ** 16
        self.models = models
        self.labels, self.target_names = [], []
        for i, t in enumerate(labels):
            self.labels.append(i)
            self.target_names.append(t)
        _df = pd.read_csv(file, quotechar='"')
        _df = _df.dropna(how='any')
        _data = np.array(_df)
        y = _data[:, class_index]
        nrange = range(np.ndim(_data))
        x = _data[:, nrange[nrange != class_index]]
        (self.x_train, self.x_test,
         self.y_train, self.y_test) = train_test_split(x,
                                                       y,
                                                       random_state=seed,
                                                       shuffle=shuffle,
                                                       stratify=y,
                                                       test_size=0.1
                                                       )
        for i, c in enumerate(self.target_names):
            self.y_train[self.y_train == c] = i
            self.y_test[self.y_test == c] = i
        self._vectr = HashingVectorizer(alternate_sign=False,
                                        n_features=self.n_features)
        self.x_train = list(self.x_train)
        self.x_test = list(self.x_test)
        self.y_train = list(self.y_train)
        self.y_test = list(self.y_test)
        self.x = self.x_train + self.x_test
        self.y = self.y_train + self.y_test
        self.x_train = self._vectr.transform(self.x_train)
        self.x_test = self._vectr.transform(self.x_test)
        self.x = self._vectr.transform(self.x)
        self.trained_models = {k: None for k in models}
        self.feature_names = None

    def evaluate_all(self, reports):
        return [self.evaluate(report)
                for report in reports]

    def _benchmark(self, clf, print_top10=True,
                   print_report=True, print_cm=True, cv=True, cvf=10):
        X_train = self.x_train
        y_train = self.y_train
        X_test = self.x_test
        y_test = self.y_test
        train_time = 0
        test_time = 0
        if not cv:
            t0 = time()
            clf.fit(X_train, y_train)
            train_time = time() - t0
            print("train time: %0.3fs" % train_time)

            t0 = time()
            pred = clf.predict(X_test)
            test_time = time() - t0
            print("test time:  %0.3fs" % test_time)

            score = metrics.accuracy_score(y_test, pred)
            print("accuracy:   %0.3f" % score)

            print("confusion matrix:")
            print(metrics.confusion_matrix(y_test, pred))
        else:
            score = cross_val_score(clf, self.x, self.y, cv=cvf)
            print("CV scores %s" % score)

        clf_descr = str(clf).split('(')[0]
        return [clf_descr, score, train_time, test_time, clf]

    def build_all(self):
        """build all classifiers in the list"""
        results = []
        benchmark = self._benchmark
        for clf, name in (
                (RidgeClassifier(tol=1e-2, solver="sag"), "rid"),
                (Perceptron(max_iter=1000), "ptc"),
                (PassiveAggressiveClassifier(n_iter=1000), "pac"),
                (KNeighborsClassifier(n_neighbors=10), "knn"),
                (RandomForestClassifier(n_estimators=100), "rfc")):
            if name in self.models:
                print('=' * 80)
                print("Training model %s " % ClassSuite.MODEL_NAMES[name])
                res = benchmark(clf)
                self.trained_models[name] = res.pop()
                results.append(res)

        for penalty in ["l2", "l1"]:
            print('=' * 80)
            print("Training models with %s penalty" % penalty.upper())
            if "svc" in self.models:
                # Train Liblinear model
                print('=' * 80)
                print("\tTraining Linear SVC model with liblinear")
                res = benchmark(LinearSVC(penalty=penalty, dual=False,
                                          tol=1e-3))
                self.trained_models["svc"] = res.pop()
                results.append(res)
            if "sgd" in self.models:
                # Train SGD model
                print('=' * 80)
                print("\tTraining Logistic Regression model with liblinear")
                res = benchmark(SGDClassifier(alpha=.0001, max_iter=1000,
                                              penalty=penalty))
                self.trained_models["sgd"] = res.pop()
                results.append(res)
        if "sgde"in self.models:
            # Train SGD with Elastic Net penalty
            print('=' * 80)
            print("Training Logistic Regression with Elastic-Net penalty")
            res = benchmark(SGDClassifier(alpha=.0001, max_iter=1000,
                                          penalty="elasticnet"))
            self.trained_models["sgde"] = res.pop()
            results.append(res)

        if "ncc" in self.models:
            # Train NearestCentroid without threshold
            print('=' * 80)
            print("Training NearestCentroid (aka Rocchio classifier)")
            res = benchmark(NearestCentroid())
            self.trained_models["ncc"] = res.pop()
            results.append(res)
        # Train sparse Naive Bayes classifiers
        if "mnb" in self.models:
            print('=' * 80)
            print("Training Multinomial Naive Bayes")
            res = benchmark(MultinomialNB(alpha=.01))
            self.trained_models["mnb"] = res.pop()
            results.append(res)

        if "bnb" in self.models:
            print('=' * 80)
            print("Training Bernoulli Naive Bayes")
            res = benchmark(BernoulliNB(alpha=.01))
            self.trained_models["bnb"] = res.pop()
            results.append(res)

        if "svcf" in self.models:
            print('=' * 80)
            print("Training LinearSVC with L1-based feature selection")
            # The smaller C, the stronger the regularization.
            # The more regularization, the more sparsity.
            res = benchmark(Pipeline([
              ('feature_selection', SelectFromModel(LinearSVC(penalty="l1", dual=False,
                                                              tol=1e-3))),
              ('classification', LinearSVC(penalty="l2"))]))
            self.trained_models["svcf"] = res.pop()
            results.append(res)
        print('=' * 80)
        results = [[x[i] for x in results] for i in range(4)]

        clf_names, score, training_time, test_time = results
        # self.training_time = np.array(training_time) / np.max(training_time)
        # self.test_time = np.array(test_time) / np.max(test_time)
        self.testing_scores = score

    def get_labelnames(self, textlabels):
        return [self.target_names[int(i)] for i in textlabels]


def most_common(L):
    """return most common item in a dictionary"""
    # get an iterable of (item, iterable) pairs
    SL = sorted((x, i) for i, x in enumerate(L))
    # print 'SL:', SL
    groups = itertools.groupby(SL, key=operator.itemgetter(0))
    # auxiliary function to get "quality" for an item

    def _auxfun(g):
        item, iterable = g
        count = 0
        min_index = len(L)
        for _, where in iterable:
            count += 1
        min_index = min(min_index, where)
    # print 'item %r, count %r, minind %r' % (item, count, min_index)
        return count, -min_index
    # pick the highest-count/earliest item
    return max(groups, key=_auxfun)[0]


if __name__ == "__main__":
    CF = ClassSuite()
    CF.build_all()
    scores = CF.testing_scores
    models = CF.models
    full_results = {ClassSuite.MODEL_NAMES[m]: s for m, s in zip(models,
                    scores)}
    np.save("clfsuite_ast", full_results)
