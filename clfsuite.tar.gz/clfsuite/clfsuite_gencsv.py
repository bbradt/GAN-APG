"""
	Generate compiled CSV file for classifier suite
"""
import csv

pos_filename = "./pos"
neg_filename = "./neg"
out_filename = "./ast.csv"

def main():
    with open(out_filename, "w") as outfile:
        outfile.write("")  # flush file

    with open(pos_filename, "r") as infile:
        for line in infile:  # assuming each line is an instance
            if len(line.strip()) == 0:
                continue
            line = line.replace('\n', '\"\n')
            
            with open(out_filename, "a") as outfile:
                outfile.write("pos, \"%s" % line)

    with open(neg_filename, "r") as infile:
        for line in infile:  # assuming each line is an instance
            if len(line.strip()) == 0:
                continue
            line = line.replace('\n', '\"\n')
            with open(out_filename, "a") as outfile:
                outfile.write("neg, \"%s" % line)

if __name__ == '__main__':
    main()
