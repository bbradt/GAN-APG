#!/bin/bash
: <<'END'
This script exports the environment variables required to run the Seq2Seq framework.
It assumes these variables are passed to the command line in the following order:
	0 - Path of the Data
	1 - Name of the vocabulary file
	2 - Name of the training file
	3 - Name of the target file
	4 - Name of the model
	5 - Number of training steps
END


export DATA_PATH=$1
export VOCAB_NAME=$2
export TRAIN_NAME=$3
export TARGET_NAME=$4
export MODEL_NAME=$5
export TRAIN_STEPS=$6

echo $DATA_PATH
echo $VOCAB_NAME
echo $TRAIN_NAME
echo $TARGET_NAME
echo $MODEL_NAME
echo $TRAIN_STEPS

export VOCAB_SOURCE=${DATA_PATH}/${VOCAB_NAME}
export VOCAB_TARGET=${DATA_PATH}/${VOCAB_NAME}
export TRAIN_SOURCES=${DATA_PATH}/${TRAIN_NAME}
export TRAIN_TARGETS=${DATA_PATH}/${TARGET_NAME}
export DEV_SOURCES=${DATA_PATH}/${TRAIN_NAME}
export DEV_TARGETS=${DATA_PATH}/${TARGET_NAME}

export DEV_TARGETS_REF=${DATA_PATH}/${TARGET_NAME}
export MODEL_DIR=${DATA_PATH}/${MODEL_NAME}_model
export PRED_DIR=${DATA_PATH}/${MODEL_NAME}_predictions
mkdir -p $MODEL_DIR
mkdir -p $PRED_DIR
