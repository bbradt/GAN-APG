#!/bin/bash
: <<'END'
	This script uses environment variables to run the prediction process for Seq2Seq.
	TODO: Integrate this more closely with the python pipeline
END

cd ../seq2seq

python -m bin.infer \
  --tasks "
    - class: DecodeText" \
  --model_dir $MODEL_DIR \
  --input_pipeline "
    class: ParallelTextInputPipeline
    params:
      source_files:
        - $DEV_SOURCES" \
  >  ${PRED_DIR}/predictions.txt
